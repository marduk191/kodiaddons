__author__ = 'bromix'

import unittest

"""
class TestCipher(unittest.TestCase):
    def setUp(self):
        pass

    def test_load_javascript(self):
        cipher = Cipher()

        java_script = ''
        with open ("html5player.js", "r") as java_script_file:
            java_script = java_script_file.read()
            pass

        json_script = cipher._load_java_script(java_script)
        jse = JsonScriptEngine(json_script)
        signature = jse.execute('299D15DC85986F6D8B7BC0E5655F758E6F14B1E33.50BCBEAE15DA02F131DAA96B640C57AAABAB20E20E2')
        pass
    pass
"""